package com.depth.chromeiconpack;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView t = new TextView(this);
        t.setText("Chrome Icon Pack ready\n\nNova Launcher kholo:\nSettings > Look & feel > Icon style > Icon theme > Chrome Icon Pack\n\nYa kisi app ke icon pe long press > Edit > icon pe tap > Chrome Icon Pack se chuno.");
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        t.setPadding(60, 60, 60, 60);
        t.setBackgroundColor(Color.BLACK);
        setContentView(t);
    }
}
